#include <iostream>
#include "Date.h"

int main(){
    Date date1{12, 5, 2020};
    date1.displayDate();
    return 0;
}